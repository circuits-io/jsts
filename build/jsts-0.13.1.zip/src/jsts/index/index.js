//= require .
//= require ./bintree
//= require ./chain
//= require ./kdtree
//= require ./quadtree
//= require ./strtree